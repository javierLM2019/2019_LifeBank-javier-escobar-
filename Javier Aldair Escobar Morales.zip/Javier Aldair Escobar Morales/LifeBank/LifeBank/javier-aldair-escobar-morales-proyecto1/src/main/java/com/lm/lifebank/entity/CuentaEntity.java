package com.lm.lifebank.entity;

import javax.persistence.*;
import java.sql.Date;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "cuenta", schema = "public", catalog = "postgres")
public class CuentaEntity {
    private int idCuenta;
    private String numeroCliente;
    private String numeroCuenta;
    private String estadoCuenta;
    private String fechaCreacion;
    private Date fechaIniPerido;
    private Date fechaFinPerido;
    private String tipoCuenta;
    private int idCliente;
    private ClienteusuarioEntity clienteusuarioByIdCliente;
    private Collection<CuentaServicioEntity> cuentaServiciosByIdCuenta;

    @Id
    @Column(name = "id_cuenta", nullable = false)
    public int getIdCuenta() {
        return idCuenta;
    }

    public void setIdCuenta(int idCuenta) {
        this.idCuenta = idCuenta;
    }

    @Basic
    @Column(name = "numero_cliente", nullable = false, length = 20)
    public String getNumeroCliente() {
        return numeroCliente;
    }

    public void setNumeroCliente(String numeroCliente) {
        this.numeroCliente = numeroCliente;
    }

    @Basic
    @Column(name = "numero_cuenta", nullable = false, length = 25)
    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    @Basic
    @Column(name = "estado_cuenta", nullable = false, length = 25)
    public String getEstadoCuenta() {
        return estadoCuenta;
    }

    public void setEstadoCuenta(String estadoCuenta) {
        this.estadoCuenta = estadoCuenta;
    }

    @Basic
    @Column(name = "fecha_creacion", nullable = false, length = 25)
    public String getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(String fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    @Basic
    @Column(name = "fecha_ini_perido", nullable = true)
    public Date getFechaIniPerido() {
        return fechaIniPerido;
    }

    public void setFechaIniPerido(Date fechaIniPerido) {
        this.fechaIniPerido = fechaIniPerido;
    }

    @Basic
    @Column(name = "fecha_fin_perido", nullable = true)
    public Date getFechaFinPerido() {
        return fechaFinPerido;
    }

    public void setFechaFinPerido(Date fechaFinPerido) {
        this.fechaFinPerido = fechaFinPerido;
    }

    @Basic
    @Column(name = "tipo_cuenta", nullable = false, length = 25)
    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    @Basic
    @Column(name = "id_cliente", nullable = false)
    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CuentaEntity that = (CuentaEntity) o;
        return idCuenta == that.idCuenta &&
                idCliente == that.idCliente &&
                Objects.equals(numeroCliente, that.numeroCliente) &&
                Objects.equals(numeroCuenta, that.numeroCuenta) &&
                Objects.equals(estadoCuenta, that.estadoCuenta) &&
                Objects.equals(fechaCreacion, that.fechaCreacion) &&
                Objects.equals(fechaIniPerido, that.fechaIniPerido) &&
                Objects.equals(fechaFinPerido, that.fechaFinPerido) &&
                Objects.equals(tipoCuenta, that.tipoCuenta);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCuenta, numeroCliente, numeroCuenta, estadoCuenta, fechaCreacion, fechaIniPerido, fechaFinPerido, tipoCuenta, idCliente);
    }

    @ManyToOne
    @JoinColumn(name = "id_cliente", referencedColumnName = "id_cliente",nullable = false , insertable=false, updatable=false)
    public ClienteusuarioEntity getClienteusuarioByIdCliente() {
        return clienteusuarioByIdCliente;
    }

    public void setClienteusuarioByIdCliente(ClienteusuarioEntity clienteusuarioByIdCliente) {
        this.clienteusuarioByIdCliente = clienteusuarioByIdCliente;
    }

    @OneToMany(mappedBy = "cuentaByIdCuenta")
    public Collection<CuentaServicioEntity> getCuentaServiciosByIdCuenta() {
        return cuentaServiciosByIdCuenta;
    }

    public void setCuentaServiciosByIdCuenta(Collection<CuentaServicioEntity> cuentaServiciosByIdCuenta) {
        this.cuentaServiciosByIdCuenta = cuentaServiciosByIdCuenta;
    }
}
