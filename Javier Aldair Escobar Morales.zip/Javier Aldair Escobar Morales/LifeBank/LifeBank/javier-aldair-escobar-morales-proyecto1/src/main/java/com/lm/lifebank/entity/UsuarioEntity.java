package com.lm.lifebank.entity;

import javax.persistence.*;
import java.sql.Date;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "usuario", schema = "public", catalog = "postgres")
public class UsuarioEntity {
    private int idUsuario;
    private String codUsuario;
    private String usuario;
    private String contra;
    private String estado;
    private Date fechaCreacion;
    private int idRolusuario;
    private Collection<ClienteusuarioEntity> clienteusuariosByIdUsuario;
    private RolXUsuarioEntity rolXUsuarioByIdRolusuario;

    @Id
    @Column(name = "id_usuario", nullable = false)
    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    @Basic
    @Column(name = "cod_usuario", nullable = true, length = 20)
    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    @Basic
    @Column(name = "usuario", nullable = true, length = 20)
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    @Basic
    @Column(name = "contra", nullable = true, length = 20)
    public String getContra() {
        return contra;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }

    @Basic
    @Column(name = "estado", nullable = true, length = 5)
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Basic
    @Column(name = "fecha_creacion", nullable = true)
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    @Basic
    @Column(name = "id_rolusuario", nullable = false)
    public int getIdRolusuario() {
        return idRolusuario;
    }

    public void setIdRolusuario(int idRolusuario) {
        this.idRolusuario = idRolusuario;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UsuarioEntity that = (UsuarioEntity) o;
        return idUsuario == that.idUsuario &&
                idRolusuario == that.idRolusuario &&
                Objects.equals(codUsuario, that.codUsuario) &&
                Objects.equals(usuario, that.usuario) &&
                Objects.equals(contra, that.contra) &&
                Objects.equals(estado, that.estado) &&
                Objects.equals(fechaCreacion, that.fechaCreacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idUsuario, codUsuario, usuario, contra, estado, fechaCreacion, idRolusuario);
    }

    @OneToMany(mappedBy = "usuarioByIdUsuario")
    public Collection<ClienteusuarioEntity> getClienteusuariosByIdUsuario() {
        return clienteusuariosByIdUsuario;
    }

    public void setClienteusuariosByIdUsuario(Collection<ClienteusuarioEntity> clienteusuariosByIdUsuario) {
        this.clienteusuariosByIdUsuario = clienteusuariosByIdUsuario;
    }

    @ManyToOne
    @JoinColumn(name = "id_rolusuario", referencedColumnName = "id_rolusuario", nullable = false, insertable = false, updatable = false)
    public RolXUsuarioEntity getRolXUsuarioByIdRolusuario() {
        return rolXUsuarioByIdRolusuario;
    }

    public void setRolXUsuarioByIdRolusuario(RolXUsuarioEntity rolXUsuarioByIdRolusuario) {
        this.rolXUsuarioByIdRolusuario = rolXUsuarioByIdRolusuario;
    }
}
