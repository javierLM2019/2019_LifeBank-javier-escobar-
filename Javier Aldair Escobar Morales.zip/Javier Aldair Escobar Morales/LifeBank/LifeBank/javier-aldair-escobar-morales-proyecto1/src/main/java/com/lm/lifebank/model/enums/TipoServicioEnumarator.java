package com.lm.lifebank.model.enums;

public enum TipoServicioEnumarator {
    presttamo("Préstamo"),
    tarjeta("Cuenta corriente con tarjeta"),
    transferencia("Transferencia");

    private String displayname;

     TipoServicioEnumarator(String displayname){
        this.displayname=displayname;
    }

    @Override
    public String toString(){
         return displayname;
    }
}
