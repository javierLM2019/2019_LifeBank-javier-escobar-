package com.lm.lifebank.entity;

import javax.persistence.*;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "rol_x_usuario", schema = "public", catalog = "postgres")
public class RolXUsuarioEntity {
    private int idRolusuario;
    private String codUsuariorol;
    private String nombreUsuario;
    private String estado;
    private int idRol;
    private RolEntity rolByIdRol;
    private Collection<UsuarioEntity> usuariosByIdRolusuario;

    @Id
    @Column(name = "id_rolusuario", nullable = false)
    public int getIdRolusuario() {
        return idRolusuario;
    }

    public void setIdRolusuario(int idRolusuario) {
        this.idRolusuario = idRolusuario;
    }

    @Basic
    @Column(name = "cod_usuariorol", nullable = true, length = 20)
    public String getCodUsuariorol() {
        return codUsuariorol;
    }

    public void setCodUsuariorol(String codUsuariorol) {
        this.codUsuariorol = codUsuariorol;
    }

    @Basic
    @Column(name = "nombre_usuario", nullable = true, length = 20)
    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    @Basic
    @Column(name = "estado", nullable = true, length = 5)
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Basic
    @Column(name = "id_rol", nullable = false)
    public int getIdRol() {
        return idRol;
    }

    public void setIdRol(int idRol) {
        this.idRol = idRol;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RolXUsuarioEntity that = (RolXUsuarioEntity) o;
        return idRolusuario == that.idRolusuario &&
                idRol == that.idRol &&
                Objects.equals(codUsuariorol, that.codUsuariorol) &&
                Objects.equals(nombreUsuario, that.nombreUsuario) &&
                Objects.equals(estado, that.estado);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idRolusuario, codUsuariorol, nombreUsuario, estado, idRol);
    }

    @ManyToOne
    @JoinColumn(name = "id_rol", referencedColumnName = "id_rol",nullable = false , insertable=false, updatable=false)
    public RolEntity getRolByIdRol() {
        return rolByIdRol;
    }

    public void setRolByIdRol(RolEntity rolByIdRol) {
        this.rolByIdRol = rolByIdRol;
    }

    @OneToMany(mappedBy = "rolXUsuarioByIdRolusuario")
    public Collection<UsuarioEntity> getUsuariosByIdRolusuario() {
        return usuariosByIdRolusuario;
    }

    public void setUsuariosByIdRolusuario(Collection<UsuarioEntity> usuariosByIdRolusuario) {
        this.usuariosByIdRolusuario = usuariosByIdRolusuario;
    }
}
