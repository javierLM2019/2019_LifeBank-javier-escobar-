package com.lm.lifebank.service;

import com.lm.lifebank.entity.CuentaEntity;
import com.lm.lifebank.model.CuentaDto;
import com.lm.lifebank.model.TipoServicio;
import com.lm.lifebank.repository.CuentaRepository;
import com.lm.lifebank.repository.MovimientoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
public class CuentaService {

    @Autowired
    CuentaRepository cuentaRepository;
    @Autowired
    MovimientoRepository movimientoRepository;

    public Map<Object, Object> getCuenta() {
        Map<Object, Object> respuesta = new HashMap<>();
        List<CuentaEntity> cuentas = cuentaRepository.findAll();
        List<CuentaDto> cuentaDtos = new ArrayList<>();
        Map<String, List<TipoServicio>> tipoServicioMap = new LinkedHashMap<>();
        cuentas.forEach(cuenta -> {
            List<TipoServicio> tipoServiciosList = new ArrayList<>();
            cuenta.getCuentaServiciosByIdCuenta().stream().forEach(catServicioEntity -> {
                TipoServicio tipoServicio = new TipoServicio();
                tipoServicio.setId(catServicioEntity.getCodServicio());
                tipoServicio.setNombre(catServicioEntity.getTipoServicio());
                tipoServiciosList.add(tipoServicio);
            });
            tipoServicioMap.put(cuenta.getTipoCuenta(), tipoServiciosList);

        });
        respuesta.put("cuentas", tipoServicioMap);
        return respuesta;
    }

    public Map<Object, Object> getMovimientos(String id, LocalDate startDate, LocalDate endDate) {
        Map<Object, Object> respuesta = new HashMap<>();
        respuesta.put("id", id);
        respuesta.put("startDate", startDate);
        respuesta.put("endDate", endDate);
        respuesta.put("transactions", movimientoRepository.findAll());
        return respuesta;
    }

}
