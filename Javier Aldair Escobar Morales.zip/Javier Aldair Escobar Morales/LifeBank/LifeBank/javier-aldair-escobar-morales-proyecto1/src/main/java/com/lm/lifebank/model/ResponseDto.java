package com.lm.lifebank.model;

import lombok.Data;

@Data
public class ResponseDto {
    private String code;
    private String message;
    private Object errors;
    private Object Response;
}
