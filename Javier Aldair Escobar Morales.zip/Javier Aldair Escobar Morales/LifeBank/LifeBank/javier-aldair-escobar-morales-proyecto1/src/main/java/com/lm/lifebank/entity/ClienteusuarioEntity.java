package com.lm.lifebank.entity;

import javax.persistence.*;
import java.sql.Date;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "clienteusuario", schema = "public", catalog = "postgres")
public class ClienteusuarioEntity {
    private int idCliente;
    private String numeroCliente;
    private String numeroIdentificacion;
    private String nombreCliente;
    private String apellidoCliente;
    private Integer telefono;
    private String direccion;
    private Date fechaNacimiento;
    private Date fechaCreacion;
    private String nacionalidad;
    private int idUsuario;
    private UsuarioEntity usuarioByIdUsuario;
    private Collection<CuentaEntity> cuentasByIdCliente;

    @Id
    @Column(name = "id_cliente", nullable = false)
    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    @Basic
    @Column(name = "numero_cliente", nullable = true, length = 20)
    public String getNumeroCliente() {
        return numeroCliente;
    }

    public void setNumeroCliente(String numeroCliente) {
        this.numeroCliente = numeroCliente;
    }

    @Basic
    @Column(name = "numero_identificacion", nullable = true, length = 9)
    public String getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public void setNumeroIdentificacion(String numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
    }

    @Basic
    @Column(name = "nombre_cliente", nullable = true, length = 20)
    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    @Basic
    @Column(name = "apellido_cliente", nullable = true, length = 20)
    public String getApellidoCliente() {
        return apellidoCliente;
    }

    public void setApellidoCliente(String apellidoCliente) {
        this.apellidoCliente = apellidoCliente;
    }

    @Basic
    @Column(name = "telefono", nullable = true, precision = 0)
    public Integer getTelefono() {
        return telefono;
    }

    public void setTelefono(Integer telefono) {
        this.telefono = telefono;
    }

    @Basic
    @Column(name = "direccion", nullable = true, length = 20)
    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    @Basic
    @Column(name = "fecha_nacimiento", nullable = true)
    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    @Basic
    @Column(name = "fecha_creacion", nullable = true)
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    @Basic
    @Column(name = "nacionalidad", nullable = true, length = 20)
    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    @Basic
    @Column(name = "id_usuario", nullable = false)
    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClienteusuarioEntity that = (ClienteusuarioEntity) o;
        return idCliente == that.idCliente &&
                idUsuario == that.idUsuario &&
                Objects.equals(numeroCliente, that.numeroCliente) &&
                Objects.equals(numeroIdentificacion, that.numeroIdentificacion) &&
                Objects.equals(nombreCliente, that.nombreCliente) &&
                Objects.equals(apellidoCliente, that.apellidoCliente) &&
                Objects.equals(telefono, that.telefono) &&
                Objects.equals(direccion, that.direccion) &&
                Objects.equals(fechaNacimiento, that.fechaNacimiento) &&
                Objects.equals(fechaCreacion, that.fechaCreacion) &&
                Objects.equals(nacionalidad, that.nacionalidad);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCliente, numeroCliente, numeroIdentificacion, nombreCliente, apellidoCliente, telefono, direccion, fechaNacimiento, fechaCreacion, nacionalidad, idUsuario);
    }

    @ManyToOne
    @JoinColumn(name = "id_usuario", referencedColumnName = "id_usuario",nullable = false , insertable=false, updatable=false)
    public UsuarioEntity getUsuarioByIdUsuario() {
        return usuarioByIdUsuario;
    }

    public void setUsuarioByIdUsuario(UsuarioEntity usuarioByIdUsuario) {
        this.usuarioByIdUsuario = usuarioByIdUsuario;
    }

    @OneToMany(mappedBy = "clienteusuarioByIdCliente")
    public Collection<CuentaEntity> getCuentasByIdCliente() {
        return cuentasByIdCliente;
    }

    public void setCuentasByIdCliente(Collection<CuentaEntity> cuentasByIdCliente) {
        this.cuentasByIdCliente = cuentasByIdCliente;
    }
}
