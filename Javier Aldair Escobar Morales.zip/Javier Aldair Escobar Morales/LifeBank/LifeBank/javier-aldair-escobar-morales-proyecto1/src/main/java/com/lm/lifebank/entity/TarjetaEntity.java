package com.lm.lifebank.entity;

import javax.persistence.*;
import java.sql.Date;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "tarjeta", schema = "public", catalog = "postgres")
public class TarjetaEntity {
    private int idTarjeta;
    private String codTarjeta;
    private String tipoTarjeta;
    private Integer monto;
    private Date fechaPago;
    private String tipoPago;
    private Date fechaTransaccion;
    private int idCatServicio;
    private Collection<CuentaServicioEntity> cuentaServiciosByIdTarjeta;

    @Id
    @Column(name = "id_tarjeta", nullable = false)
    public int getIdTarjeta() {
        return idTarjeta;
    }

    public void setIdTarjeta(int idTarjeta) {
        this.idTarjeta = idTarjeta;
    }

    @Basic
    @Column(name = "cod_tarjeta", nullable = true, length = 20)
    public String getCodTarjeta() {
        return codTarjeta;
    }

    public void setCodTarjeta(String codTarjeta) {
        this.codTarjeta = codTarjeta;
    }

    @Basic
    @Column(name = "tipo_tarjeta", nullable = true, length = 10)
    public String getTipoTarjeta() {
        return tipoTarjeta;
    }

    public void setTipoTarjeta(String tipoTarjeta) {
        this.tipoTarjeta = tipoTarjeta;
    }

    @Basic
    @Column(name = "monto", nullable = true, precision = 0)
    public Integer getMonto() {
        return monto;
    }

    public void setMonto(Integer monto) {
        this.monto = monto;
    }

    @Basic
    @Column(name = "fecha_pago", nullable = true)
    public Date getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(Date fechaPago) {
        this.fechaPago = fechaPago;
    }

    @Basic
    @Column(name = "tipo_pago", nullable = true, length = 20)
    public String getTipoPago() {
        return tipoPago;
    }

    public void setTipoPago(String tipoPago) {
        this.tipoPago = tipoPago;
    }

    @Basic
    @Column(name = "fecha_transaccion", nullable = false)
    public Date getFechaTransaccion() {
        return fechaTransaccion;
    }

    public void setFechaTransaccion(Date fechaTransaccion) {
        this.fechaTransaccion = fechaTransaccion;
    }

    @Basic
    @Column(name = "id_cat_servicio", nullable = false)
    public int getIdCatServicio() {
        return idCatServicio;
    }

    public void setIdCatServicio(int idCatServicio) {
        this.idCatServicio = idCatServicio;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TarjetaEntity that = (TarjetaEntity) o;
        return idTarjeta == that.idTarjeta &&
                idCatServicio == that.idCatServicio &&
                Objects.equals(codTarjeta, that.codTarjeta) &&
                Objects.equals(tipoTarjeta, that.tipoTarjeta) &&
                Objects.equals(monto, that.monto) &&
                Objects.equals(fechaPago, that.fechaPago) &&
                Objects.equals(tipoPago, that.tipoPago) &&
                Objects.equals(fechaTransaccion, that.fechaTransaccion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTarjeta, codTarjeta, tipoTarjeta, monto, fechaPago, tipoPago, fechaTransaccion, idCatServicio);
    }

    @OneToMany(mappedBy = "tarjetaByIdTarjeta")
    public Collection<CuentaServicioEntity> getCuentaServiciosByIdTarjeta() {
        return cuentaServiciosByIdTarjeta;
    }

    public void setCuentaServiciosByIdTarjeta(Collection<CuentaServicioEntity> cuentaServiciosByIdTarjeta) {
        this.cuentaServiciosByIdTarjeta = cuentaServiciosByIdTarjeta;
    }
}
