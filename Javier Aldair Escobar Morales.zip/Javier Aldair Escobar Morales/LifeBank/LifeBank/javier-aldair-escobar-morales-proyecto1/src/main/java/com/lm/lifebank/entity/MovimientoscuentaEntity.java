package com.lm.lifebank.entity;

import javax.persistence.*;
import java.math.BigInteger;
import java.sql.Date;
import java.util.Objects;

@Entity
@Table(name = "movimientoscuenta", schema = "public", catalog = "bd_lifebank")
public class MovimientoscuentaEntity {
    private int idmovimientoscuenta;
    private Integer idcuenta;
    private BigInteger monto;
    private String descripcion;
    private Date fechamovimeitno;

    @Id
    @Column(name = "idmovimientoscuenta", nullable = false)
    public int getIdmovimientoscuenta() {
        return idmovimientoscuenta;
    }

    public void setIdmovimientoscuenta(int idmovimientoscuenta) {
        this.idmovimientoscuenta = idmovimientoscuenta;
    }

    @Basic
    @Column(name = "idcuenta", nullable = true)
    public Integer getIdcuenta() {
        return idcuenta;
    }

    public void setIdcuenta(Integer idcuenta) {
        this.idcuenta = idcuenta;
    }

    @Basic
    @Column(name = "monto", nullable = true, precision = 0)
    public BigInteger getMonto() {
        return monto;
    }

    public void setMonto(BigInteger monto) {
        this.monto = monto;
    }

    @Basic
    @Column(name = "descripcion", nullable = true, length = 50)
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Basic
    @Column(name = "fechamovimeitno", nullable = true)
    public Date getFechamovimeitno() {
        return fechamovimeitno;
    }

    public void setFechamovimeitno(Date fechamovimeitno) {
        this.fechamovimeitno = fechamovimeitno;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MovimientoscuentaEntity that = (MovimientoscuentaEntity) o;
        return idmovimientoscuenta == that.idmovimientoscuenta &&
                Objects.equals(idcuenta, that.idcuenta) &&
                Objects.equals(monto, that.monto) &&
                Objects.equals(descripcion, that.descripcion) &&
                Objects.equals(fechamovimeitno, that.fechamovimeitno);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idmovimientoscuenta, idcuenta, monto, descripcion, fechamovimeitno);
    }
}
