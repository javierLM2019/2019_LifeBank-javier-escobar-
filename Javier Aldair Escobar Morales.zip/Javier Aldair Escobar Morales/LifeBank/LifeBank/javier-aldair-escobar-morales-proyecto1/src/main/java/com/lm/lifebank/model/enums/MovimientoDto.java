package com.lm.lifebank.model.enums;

public class MovimientoDto {

}
