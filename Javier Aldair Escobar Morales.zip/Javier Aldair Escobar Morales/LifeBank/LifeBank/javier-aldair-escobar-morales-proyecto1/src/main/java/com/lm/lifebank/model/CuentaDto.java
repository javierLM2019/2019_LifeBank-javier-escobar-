package com.lm.lifebank.model;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class CuentaDto {

   Map<String, List<TipoServicio>> tipoServicioMap;
}
