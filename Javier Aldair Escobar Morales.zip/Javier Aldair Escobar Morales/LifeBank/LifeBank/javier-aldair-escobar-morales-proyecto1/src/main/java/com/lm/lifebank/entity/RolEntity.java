package com.lm.lifebank.entity;

import javax.persistence.*;
import java.sql.Date;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "rol", schema = "public", catalog = "postgres")
public class RolEntity {
    private int idRol;
    private String nombreRol;
    private String descripcionRol;
    private String estado;
    private Date fechaCreacion;
    private Collection<RolXUsuarioEntity> rolXUsuariosByIdRol;

    @Id
    @Column(name = "id_rol", nullable = false)
    public int getIdRol() {
        return idRol;
    }

    public void setIdRol(int idRol) {
        this.idRol = idRol;
    }

    @Basic
    @Column(name = "nombre_rol", nullable = true, length = 30)
    public String getNombreRol() {
        return nombreRol;
    }

    public void setNombreRol(String nombreRol) {
        this.nombreRol = nombreRol;
    }

    @Basic
    @Column(name = "descripcion_rol", nullable = true, length = 30)
    public String getDescripcionRol() {
        return descripcionRol;
    }

    public void setDescripcionRol(String descripcionRol) {
        this.descripcionRol = descripcionRol;
    }

    @Basic
    @Column(name = "estado", nullable = true, length = 2)
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Basic
    @Column(name = "fecha_creacion", nullable = false)
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RolEntity rolEntity = (RolEntity) o;
        return idRol == rolEntity.idRol &&
                Objects.equals(nombreRol, rolEntity.nombreRol) &&
                Objects.equals(descripcionRol, rolEntity.descripcionRol) &&
                Objects.equals(estado, rolEntity.estado) &&
                Objects.equals(fechaCreacion, rolEntity.fechaCreacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idRol, nombreRol, descripcionRol, estado, fechaCreacion);
    }

    @OneToMany(mappedBy = "rolByIdRol")
    public Collection<RolXUsuarioEntity> getRolXUsuariosByIdRol() {
        return rolXUsuariosByIdRol;
    }

    public void setRolXUsuariosByIdRol(Collection<RolXUsuarioEntity> rolXUsuariosByIdRol) {
        this.rolXUsuariosByIdRol = rolXUsuariosByIdRol;
    }
}
