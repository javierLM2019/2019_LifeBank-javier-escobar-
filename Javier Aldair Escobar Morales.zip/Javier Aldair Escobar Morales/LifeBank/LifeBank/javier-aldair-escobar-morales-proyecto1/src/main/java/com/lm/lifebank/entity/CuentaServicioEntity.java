package com.lm.lifebank.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cuenta_servicio", schema = "public", catalog = "postgres")
public class CuentaServicioEntity {
    private int idCatServicio;
    private String codServicio;
    private String tipoServicio;
    private String estadoServicio;
    private String fechaCreacion;
    private int idCuenta;
    private int idPrestamo;
    private int idTarjeta;
    private int idPrestabancario;
    private CuentaEntity cuentaByIdCuenta;
    private PrestamoEntity prestamoByIdPrestamo;
    private TarjetaEntity tarjetaByIdTarjeta;

    @Id
    @Column(name = "id_cat_servicio", nullable = false)
    public int getIdCatServicio() {
        return idCatServicio;
    }

    public void setIdCatServicio(int idCatServicio) {
        this.idCatServicio = idCatServicio;
    }

    @Basic
    @Column(name = "cod_servicio", nullable = true, length = 25)
    public String getCodServicio() {
        return codServicio;
    }

    public void setCodServicio(String codServicio) {
        this.codServicio = codServicio;
    }

    @Basic
    @Column(name = "tipo_servicio", nullable = true, length = 25)
    public String getTipoServicio() {
        return tipoServicio;
    }

    public void setTipoServicio(String tipoServicio) {
        this.tipoServicio = tipoServicio;
    }

    @Basic
    @Column(name = "estado_servicio", nullable = true, length = 25)
    public String getEstadoServicio() {
        return estadoServicio;
    }

    public void setEstadoServicio(String estadoServicio) {
        this.estadoServicio = estadoServicio;
    }

    @Basic
    @Column(name = "fecha_creacion", nullable = true, length = 25)
    public String getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(String fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    @Basic
    @Column(name = "id_cuenta", nullable = false)
    public int getIdCuenta() {
        return idCuenta;
    }

    public void setIdCuenta(int idCuenta) {
        this.idCuenta = idCuenta;
    }

    @Basic
    @Column(name = "id_prestamo", nullable = false)
    public int getIdPrestamo() {
        return idPrestamo;
    }

    public void setIdPrestamo(int idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    @Basic
    @Column(name = "id_tarjeta", nullable = false)
    public int getIdTarjeta() {
        return idTarjeta;
    }

    public void setIdTarjeta(int idTarjeta) {
        this.idTarjeta = idTarjeta;
    }



    public void setIdPrestabancario(int idPrestabancario) {
        this.idPrestabancario = idPrestabancario;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CuentaServicioEntity that = (CuentaServicioEntity) o;
        return idCatServicio == that.idCatServicio &&
                idCuenta == that.idCuenta &&
                idPrestamo == that.idPrestamo &&
                idTarjeta == that.idTarjeta &&
                idPrestabancario == that.idPrestabancario &&
                Objects.equals(codServicio, that.codServicio) &&
                Objects.equals(tipoServicio, that.tipoServicio) &&
                Objects.equals(estadoServicio, that.estadoServicio) &&
                Objects.equals(fechaCreacion, that.fechaCreacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCatServicio, codServicio, tipoServicio, estadoServicio, fechaCreacion, idCuenta, idPrestamo, idTarjeta, idPrestabancario);
    }

    @ManyToOne
    @JoinColumn(name = "id_cuenta", referencedColumnName = "id_cuenta",nullable = false , insertable=false, updatable=false)
    public CuentaEntity getCuentaByIdCuenta() {
        return cuentaByIdCuenta;
    }

    public void setCuentaByIdCuenta(CuentaEntity cuentaByIdCuenta) {
        this.cuentaByIdCuenta = cuentaByIdCuenta;
    }

    @ManyToOne
    @JoinColumn(name = "id_prestamo", referencedColumnName = "id_prestamo",nullable = false , insertable=false, updatable=false)
    public PrestamoEntity getPrestamoByIdPrestamo() {
        return prestamoByIdPrestamo;
    }

    public void setPrestamoByIdPrestamo(PrestamoEntity prestamoByIdPrestamo) {
        this.prestamoByIdPrestamo = prestamoByIdPrestamo;
    }

    @ManyToOne
    @JoinColumn(name = "id_tarjeta", referencedColumnName = "id_tarjeta",nullable = false , insertable=false, updatable=false)
    public TarjetaEntity getTarjetaByIdTarjeta() {
        return tarjetaByIdTarjeta;
    }

    public void setTarjetaByIdTarjeta(TarjetaEntity tarjetaByIdTarjeta) {
        this.tarjetaByIdTarjeta = tarjetaByIdTarjeta;
    }
}
