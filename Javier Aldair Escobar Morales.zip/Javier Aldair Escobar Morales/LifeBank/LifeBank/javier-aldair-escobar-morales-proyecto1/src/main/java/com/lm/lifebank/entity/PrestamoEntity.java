package com.lm.lifebank.entity;

import javax.persistence.*;
import java.sql.Date;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "prestamo", schema = "public", catalog = "postgres")
public class PrestamoEntity {
    private int idPrestamo;
    private String codPrestamos;
    private Date fechaPrestamo;
    private Date fechaDevuelta;
    private Date fechaCreacion;
    private Integer monto;
    private String descripcion;
    private int idCatServicio;
    private Collection<CuentaServicioEntity> cuentaServiciosByIdPrestamo;

    @Id
    @Column(name = "id_prestamo", nullable = false)
    public int getIdPrestamo() {
        return idPrestamo;
    }

    public void setIdPrestamo(int idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    @Basic
    @Column(name = "cod_prestamos", nullable = true, length = 10)
    public String getCodPrestamos() {
        return codPrestamos;
    }

    public void setCodPrestamos(String codPrestamos) {
        this.codPrestamos = codPrestamos;
    }

    @Basic
    @Column(name = "fecha_prestamo", nullable = true)
    public Date getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(Date fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    @Basic
    @Column(name = "fecha_devuelta", nullable = true)
    public Date getFechaDevuelta() {
        return fechaDevuelta;
    }

    public void setFechaDevuelta(Date fechaDevuelta) {
        this.fechaDevuelta = fechaDevuelta;
    }

    @Basic
    @Column(name = "fecha_creacion", nullable = true)
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    @Basic
    @Column(name = "monto", nullable = true, precision = 0)
    public Integer getMonto() {
        return monto;
    }

    public void setMonto(Integer monto) {
        this.monto = monto;
    }

    @Basic
    @Column(name = "descripcion", nullable = true, length = 50)
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Basic
    @Column(name = "id_cat_servicio", nullable = false)
    public int getIdCatServicio() {
        return idCatServicio;
    }

    public void setIdCatServicio(int idCatServicio) {
        this.idCatServicio = idCatServicio;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PrestamoEntity that = (PrestamoEntity) o;
        return idPrestamo == that.idPrestamo &&
                idCatServicio == that.idCatServicio &&
                Objects.equals(codPrestamos, that.codPrestamos) &&
                Objects.equals(fechaPrestamo, that.fechaPrestamo) &&
                Objects.equals(fechaDevuelta, that.fechaDevuelta) &&
                Objects.equals(fechaCreacion, that.fechaCreacion) &&
                Objects.equals(monto, that.monto) &&
                Objects.equals(descripcion, that.descripcion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPrestamo, codPrestamos, fechaPrestamo, fechaDevuelta, fechaCreacion, monto, descripcion, idCatServicio);
    }

    @OneToMany(mappedBy = "prestamoByIdPrestamo")
    public Collection<CuentaServicioEntity> getCuentaServiciosByIdPrestamo() {
        return cuentaServiciosByIdPrestamo;
    }

    public void setCuentaServiciosByIdPrestamo(Collection<CuentaServicioEntity> cuentaServiciosByIdPrestamo) {
        this.cuentaServiciosByIdPrestamo = cuentaServiciosByIdPrestamo;
    }
}
