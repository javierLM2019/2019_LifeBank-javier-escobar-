package com.lm.lifebank.controller;

import com.lm.lifebank.service.CuentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/cuenta")
@RestController
public class CuentaController {
    @Autowired
    CuentaService cuentaService;

    @GetMapping("/all")
    public ResponseEntity getCuentas(){
        try {
            return new ResponseEntity<>(cuentaService.getCuenta(), HttpStatus.ACCEPTED);

        }
        catch (Exception e){
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }

    }

}
