package com.LifeBank.LifeBank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifeBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(LifeBankApplication.class, args);
	}

}
