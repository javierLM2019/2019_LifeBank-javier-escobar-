package com.LifeBank.ModelPojo;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Producto {

	@Id
	@GeneratedValue
	private Long id;
	private String numProducto;
	private String nombProducto;
	private double preProducto;
	private String status_producto;
	private String catProducto;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNumProducto() {
		return numProducto;
	}
	public void setNumProducto(String numProducto) {
		this.numProducto = numProducto;
	}
	public String getNombProducto() {
		return nombProducto;
	}
	public void setNombProducto(String nombProducto) {
		this.nombProducto = nombProducto;
	}
	public double getPreProducto() {
		return preProducto;
	}
	public void setPreProducto(double preProducto) {
		this.preProducto = preProducto;
	}
	public String getStatus_producto() {
		return status_producto;
	}
	public void setStatus_producto(String status_producto) {
		this.status_producto = status_producto;
	}
	public String getCatProducto() {
		return catProducto;
	}
	public void setCatProducto(String catProducto) {
		this.catProducto = catProducto;
	}
	
}
