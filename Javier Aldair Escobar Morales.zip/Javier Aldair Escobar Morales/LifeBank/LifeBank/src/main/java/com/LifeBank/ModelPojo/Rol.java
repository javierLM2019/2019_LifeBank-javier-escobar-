package com.LifeBank.ModelPojo;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Rol {

	@Id
	@GeneratedValue
	private Long id;
	private String rol_name;
	private String rol_status;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getRol_name() {
		return rol_name;
	}
	public void setRol_name(String rol_name) {
		this.rol_name = rol_name;
	}
	public String getRol_status() {
		return rol_status;
	}
	public void setRol_status(String rol_status) {
		this.rol_status = rol_status;
	}
	
	
}
