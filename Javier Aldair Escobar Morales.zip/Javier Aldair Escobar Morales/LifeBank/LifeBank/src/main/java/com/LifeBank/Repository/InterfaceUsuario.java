package com.LifeBank.Repository;

import java.util.List;

import javax.persistence.Entity;

import org.springframework.data.jpa.repository.JpaRepository;

import com.LifeBank.ModelPojo.Usuario;

public interface InterfaceUsuario extends JpaRepository<Usuario, Long>{

}
